/*!
 * ${copyright}
 */
sap.ui.define(["./../library","sap/ui/core/Control","./ExampleRenderer"],function(e,r,n){"use strict";var t=r.extend("nl.gasunie.workzone.library.controls.Example",{metadata:{library:"nl.gasunie.workzone.library",properties:{text:{type:"string",defaultValue:null}},events:{press:{}}},renderer:n});return t},true);